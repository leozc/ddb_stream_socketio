var async = require('async');
var AWS = require('aws-sdk');
var fs = require('fs');
var zlib = require('zlib');
var useragent = require('useragent');
var compareVersion = require('compare-version');
useragent(true);

console.log('Loading function');
var aws = require('aws-sdk');
//var async = require('async');

var doc = require('dynamodb-doc');
var dynamo = new doc.DynamoDB();
var sns = new AWS.SNS();

String.prototype.hashCode = function(){
	var hash = 0;
	if (this.length == 0) return hash;
	for (i = 0; i < this.length; i++) {
		char = this.charCodeAt(i);
		hash = ((hash<<5)-hash)+char;
		hash = hash & hash; // Convert to 32bit integer
	}
	return hash;
}
var COMPAT_VER_INCLUSIVE='3.1.2'
exports.handler = function(event_raw, context) {
  var event = event_raw.body;

  console.log('Received event:', JSON.stringify(event_raw, null, 2));
  console.log('Received context:', JSON.stringify(context, null, 2));

  var operation = event.operation;
  var tableName = event_raw.tb_deivce;
  var app_arn = event_raw.sf_push_app_arn; // from env variable

  var agentRaw = event_raw["user-agent"]
  var agent = useragent.parse(agentRaw);

	//source: 'SwiftFinder/3.1.2 (iPhone; iOS 9.2.1; Scale/2.00)'
	var currentVersion = agent.source.split(" ",1)[0].split('/')[1]

	// we now use 3.1.2
	var config_ep = event_raw.sf_config_ep; //unknown
	if (compareVersion(currentVersion, COMPAT_VER_INCLUSIVE)<=0){
		var config_ep = event_raw.sf_config_ep_old;
	}
	var mp_url = event_raw.sf_mp_url;
	var mp_enabled = Boolean(event_raw.sf_mp_enabled);
	var mp_last_update = parseInt(event_raw.sf_mp_last_update);

  if (!tableName || !app_arn)
    context.fail(new Error("503: Environment error"));

  switch (operation) {
    /**
     *  we use dynamoDB + SNS to maintain the meta and device tokens
     */

    case 'register':
			var tz_value = 9999999; // code an illegal timezone
			var user_id = 'UNKNOWN';
			if (event.data.custom_user_data.hasOwnProperty("time_zone")){
				tz_value = event.data.custom_user_data.time_zone;
			}
			if (event.data.custom_user_data.hasOwnProperty("user_id")){
				user_id = event.data.custom_user_data.user_id;
			}
      itemPayload = {
        "token": event.data.token,
        "custom_user_data": event.data.custom_user_data,
        "timestamp": Date.now(),
				"user_tz": tz_value,
				"user_id":user_id,
        //"owner_id": event.data.owner_id, //TODO: we want to associate this with a owner,but not now
        "latlong": [event.data.lat, event.data.long],
        //"lost" : false
      };
      event.payload = {
        "TableName": tableName,
        "Item": itemPayload
      };
      dynamo.putItem(event.payload, function(err, data) {
        if (err) {
          console.error(err, err.stack); // an error occurred
          context.fail(new Error("503:" + JSON.stringify(err)));
        } else {
          // successful response, all metadata stored in dynamoDB
          sns.createPlatformEndpoint({
            PlatformApplicationArn: app_arn,
            Token: itemPayload.token,
            CustomUserData: JSON.stringify(event.data.custom_user_data)
          }, function(snsError, snsData) {
            // we ignore the case where SNS complains duplicated token but diff attributes
            if (snsError && snsError.message.indexOf("already exists with the same Token") <0) {
              console.error(snsError, snsError.stack);
              context.fail(new Error("503:" + JSON.stringify(snsError)));
            } else {
              console.log(snsData);
              context.succeed({
                "status": "ok"
              })
            }
          });
        }
      });

      break;
    case 'discover':
      //TODO: read from a memcache - or dynamoDB?
      var owner_id = undefined;
      var event_data_turn_on_ad = false;

      if (event.data) {
          if (event.data.turn_on_ad) {
            event_data_turn_on_ad = true;
          }
          else {
            if (event.data.owner_id){
              event_data_turn_on_ad = Math.abs(event.data.owner_id) % 10 > 110 ; // always false now
            }
          }
      }

      result = {
        'sf_client.register': {
          'status': true
        },
        'sf_object.createOrUpdate': {
          'status': false
        },
        'sf_object.read': {
          'status': false
        },
        'sf_object.listByOwner': {
          'status': false
        },
        'sf_object_history.listByOwner': {
          'status': false
        },
        'sf_option.ads.enabled': {
          'status': event_data_turn_on_ad,
          'frequency': 5
        },
        'sf_config': {
          'ios': config_ep,
					'android': config_ep
        },
				'sf_marketplace': {
					'url' : mp_url,
					'enabled': mp_enabled,
					'last_update': mp_last_update
				}
      };
      context.succeed({
        "status": "ok",
        "data": result
      });
      break;
    case 'echo':
      context.succeed({
        "status": "ok",
        "data": event.payload
      });
      break;
    case 'ping':
      context.succeed({
        "status": "ok",
        "message": "pong"
      });
      break;
    default:
      context.fail(new Error('"400:Unrecognized operation ' + operation + '"'));
  }

};
